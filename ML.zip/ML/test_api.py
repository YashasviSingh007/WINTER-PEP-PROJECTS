import urllib.request, json, time

time.sleep(1)
r = urllib.request.urlopen('http://localhost:5000/api/datasets')
datasets = json.loads(r.read())
print('Datasets:', list(datasets.keys()))

req = urllib.request.Request(
    'http://localhost:5000/api/analyze',
    data=json.dumps({'dataset_id': 'wine'}).encode(),
    headers={'Content-Type': 'application/json'}
)
r = urllib.request.urlopen(req)
data = json.loads(r.read())
a = data['analysis']
recs = data['recommendations']
print('Wine: {} samples, {} features, task={}'.format(a['n_samples'], a['n_features'], a['task_type']))
print('Top recommendation: {} (score={})'.format(recs[0]['name'], recs[0]['score']))
print('All API endpoints working!')

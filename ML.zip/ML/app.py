"""
ML Explorer — Flask Web Application
Provides REST API endpoints and SSE streaming for real-time training logs.
"""

import sys
import os
# Ensure UTF-8 output on Windows (avoids cp1252 emoji encoding errors)
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

import json
import queue
import threading
from flask import Flask, jsonify, request, Response, render_template
from ml_engine import (
    DATASETS, analyze_dataset, recommend_algorithms,
    train_and_evaluate
)

app = Flask(__name__)


# ─────────────────────────────────────────────
#  MAIN PAGE
# ─────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


# ─────────────────────────────────────────────
#  API: List Datasets
# ─────────────────────────────────────────────

@app.route("/api/datasets")
def get_datasets():
    return jsonify(DATASETS)


# ─────────────────────────────────────────────
#  API: Analyze Dataset
# ─────────────────────────────────────────────

@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    dataset_id = data.get("dataset_id")
    if not dataset_id or dataset_id not in DATASETS:
        return jsonify({"error": "Invalid dataset_id"}), 400

    try:
        analysis = analyze_dataset(dataset_id)
        recommendations = recommend_algorithms(analysis)
        return jsonify({
            "analysis": analysis,
            "recommendations": recommendations
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────
#  API: Train Model (SSE streaming)
# ─────────────────────────────────────────────

@app.route("/api/train", methods=["GET"])
def train():
    dataset_id = request.args.get("dataset_id")
    model_id = request.args.get("model_id")

    if not dataset_id or dataset_id not in DATASETS:
        return jsonify({"error": "Invalid dataset_id"}), 400

    log_queue = queue.Queue()
    result_holder = {}

    def progress_callback(msg):
        log_queue.put({"type": "log", "message": msg})

    def run_training():
        try:
            result = train_and_evaluate(dataset_id, model_id, progress_callback)
            result_holder["data"] = result
            log_queue.put({"type": "done", "result": result})
        except Exception as e:
            log_queue.put({"type": "error", "message": str(e)})

    thread = threading.Thread(target=run_training, daemon=True)
    thread.start()

    def generate():
        while True:
            try:
                item = log_queue.get(timeout=60)
                yield f"data: {json.dumps(item)}\n\n"
                if item["type"] in ("done", "error"):
                    break
            except queue.Empty:
                yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"

    return Response(
        generate(),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no"
        }
    )


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print("ML Explorer running at http://localhost:5000")
    app.run(debug=False, threaded=True, port=5000, use_reloader=False)

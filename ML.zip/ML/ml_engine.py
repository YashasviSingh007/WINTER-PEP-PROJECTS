"""
ML Engine — Core logic for dataset loading, analysis, recommendation, training, and evaluation.
"""

import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_auc_score, mean_squared_error, r2_score,
    mean_absolute_error
)
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, GradientBoostingClassifier, GradientBoostingRegressor
from sklearn.linear_model import LogisticRegression, LinearRegression, Ridge
from sklearn.svm import SVC, SVR
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.naive_bayes import GaussianNB
import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────
#  DATASET REGISTRY
# ─────────────────────────────────────────────

DATASETS = {
    "iris": {
        "name": "Iris Flower",
        "description": "Classic multi-class classification of iris flowers into 3 species based on petal/sepal dimensions.",
        "icon": "🌸",
        "task": "classification",
        "size": "150 samples × 4 features",
        "difficulty": "Easy"
    },
    "wine": {
        "name": "Wine Quality",
        "description": "Classify wines into 3 categories based on 13 chemical properties.",
        "icon": "🍷",
        "task": "classification",
        "size": "178 samples × 13 features",
        "difficulty": "Medium"
    },
    "breast_cancer": {
        "name": "Breast Cancer",
        "description": "Binary classification: predict malignant vs benign tumors from 30 medical features.",
        "icon": "🏥",
        "task": "classification",
        "size": "569 samples × 30 features",
        "difficulty": "Medium"
    },
    "diabetes": {
        "name": "Diabetes Progression",
        "description": "Regression task: predict diabetes disease progression one year after baseline.",
        "icon": "💉",
        "task": "regression",
        "size": "442 samples × 10 features",
        "difficulty": "Medium"
    },
    "california_housing": {
        "name": "California Housing",
        "description": "Regression: predict median house values from 8 census-derived features.",
        "icon": "🏠",
        "task": "regression",
        "size": "20,640 samples × 8 features",
        "difficulty": "Hard"
    },
    "digits": {
        "name": "Handwritten Digits",
        "description": "Multi-class classification: recognize handwritten digits 0–9 from 8×8 pixel images.",
        "icon": "🔢",
        "task": "classification",
        "size": "1,797 samples × 64 features",
        "difficulty": "Hard"
    }
}


def load_dataset(dataset_id):
    """Load and return a dataset as (X_df, y_series, feature_names, target_name, task_type)."""
    if dataset_id == "iris":
        data = datasets.load_iris()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target_names[data.target], name="species")
        return X, y, data.feature_names, "species", "classification"

    elif dataset_id == "wine":
        data = datasets.load_wine()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series([f"Class {c}" for c in data.target], name="wine_class")
        return X, y, data.feature_names, "wine_class", "classification"

    elif dataset_id == "breast_cancer":
        data = datasets.load_breast_cancer()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target_names[data.target], name="diagnosis")
        return X, y, data.feature_names, "diagnosis", "classification"

    elif dataset_id == "diabetes":
        data = datasets.load_diabetes()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target, name="progression")
        return X, y, data.feature_names, "progression", "regression"

    elif dataset_id == "california_housing":
        data = datasets.fetch_california_housing()
        X = pd.DataFrame(data.data, columns=data.feature_names)
        y = pd.Series(data.target, name="median_house_value")
        return X, y, data.feature_names, "median_house_value", "regression"

    elif dataset_id == "digits":
        data = datasets.load_digits()
        feature_names = [f"pixel_{i}" for i in range(data.data.shape[1])]
        X = pd.DataFrame(data.data, columns=feature_names)
        y = pd.Series(data.target.astype(str), name="digit")
        return X, y, feature_names, "digit", "classification"

    else:
        raise ValueError(f"Unknown dataset: {dataset_id}")


# ─────────────────────────────────────────────
#  DATASET ANALYSIS
# ─────────────────────────────────────────────

def analyze_dataset(dataset_id):
    """Return a comprehensive analysis dictionary for the dataset."""
    X, y, feature_names, target_name, task_type = load_dataset(dataset_id)
    df = X.copy()
    df[target_name] = y

    n_samples, n_features = X.shape
    null_counts = X.isnull().sum().to_dict()
    null_counts = {k: int(v) for k, v in null_counts.items()}
    total_nulls = sum(null_counts.values())

    # Basic stats
    stats = X.describe().round(3).to_dict()

    # Target distribution
    if task_type == "classification":
        dist = y.value_counts().to_dict()
        dist = {str(k): int(v) for k, v in dist.items()}
        n_classes = len(dist)
        is_balanced = max(dist.values()) / (min(dist.values()) + 1e-9) < 1.5
    else:
        dist = {
            "min": float(round(y.min(), 3)),
            "max": float(round(y.max(), 3)),
            "mean": float(round(y.mean(), 3)),
            "std": float(round(y.std(), 3))
        }
        n_classes = None
        is_balanced = None

    # Correlation (top 5 features with highest variance for readability)
    corr_matrix = X.corr().round(3)
    top_features = list(X.var().nlargest(min(6, n_features)).index)
    top_corr = corr_matrix.loc[top_features, top_features].to_dict()

    analysis = {
        "dataset_id": dataset_id,
        "task_type": task_type,
        "n_samples": n_samples,
        "n_features": n_features,
        "feature_names": list(feature_names),
        "target_name": target_name,
        "null_counts": null_counts,
        "total_nulls": total_nulls,
        "target_distribution": dist,
        "n_classes": n_classes,
        "is_balanced": is_balanced,
        "stats": stats,
        "top_corr_features": top_features,
        "correlation": top_corr,
        "data_quality": "Good" if total_nulls == 0 else "Needs Cleaning",
    }

    return analysis


# ─────────────────────────────────────────────
#  ALGORITHM RECOMMENDATION
# ─────────────────────────────────────────────

def recommend_algorithms(analysis):
    """
    Rule-based recommender that suggests the top 3 algorithms with explanations.
    Returns a list of dicts: {name, id, reason, pros, cons, score}.
    """
    task = analysis["task_type"]
    n = analysis["n_samples"]
    f = analysis["n_features"]
    balanced = analysis.get("is_balanced", True)
    n_classes = analysis.get("n_classes", 2)

    recommendations = []

    if task == "classification":
        # Random Forest — almost always good
        rf_reason = (
            f"With {n} samples and {f} features, Random Forest excels at handling "
            f"{'imbalanced' if not balanced else 'balanced'} data. It builds many decision trees and "
            "combines their votes, making it robust and highly accurate."
        )
        recommendations.append({
            "name": "Random Forest",
            "id": "random_forest",
            "reason": rf_reason,
            "pros": ["Handles noise well", "Feature importance built-in", "No feature scaling needed"],
            "cons": ["Slower on very large datasets", "Less interpretable than single tree"],
            "score": 95 if n > 100 else 85
        })

        # Logistic Regression — great for smaller datasets
        lr_score = 90 if (n < 5000 and f < 50) else 75
        recommendations.append({
            "name": "Logistic Regression",
            "id": "logistic_regression",
            "reason": (
                f"Logistic Regression is a simple yet powerful baseline for {'binary' if n_classes == 2 else 'multi-class'} "
                "classification. It's fast, interpretable, and provides probability estimates."
            ),
            "pros": ["Fast training", "Highly interpretable", "Probabilistic output"],
            "cons": ["Assumes linear decision boundary", "Needs feature scaling"],
            "score": lr_score
        })

        # SVM — good for high-dimensional small datasets
        if f > 10 or n < 1000:
            recommendations.append({
                "name": "Support Vector Machine (SVM)",
                "id": "svm",
                "reason": (
                    f"SVM is ideal for datasets with {f} features where the classes might not be linearly separable. "
                    "It finds the optimal hyperplane that maximizes the margin between classes."
                ),
                "pros": ["Excellent in high-dimensional spaces", "Memory efficient", "Versatile kernels"],
                "cons": ["Slow on large datasets", "Sensitive to feature scaling", "No probability by default"],
                "score": 88 if f > 10 else 80
            })
        else:
            recommendations.append({
                "name": "Gradient Boosting",
                "id": "gradient_boosting",
                "reason": (
                    "Gradient Boosting iteratively builds trees, each correcting errors of the previous one. "
                    "It's one of the most powerful algorithms for structured/tabular data."
                ),
                "pros": ["State-of-the-art accuracy", "Handles mixed features", "Flexible loss functions"],
                "cons": ["Many hyperparameters to tune", "Prone to overfitting without care", "Slower training"],
                "score": 92
            })

    else:  # regression
        recommendations.append({
            "name": "Random Forest Regressor",
            "id": "random_forest",
            "reason": (
                f"For this regression task with {n} samples, Random Forest Regressor averages predictions "
                "from many decision trees, effectively capturing non-linear relationships in the data."
            ),
            "pros": ["Handles non-linearity", "Robust to outliers", "Feature importance"],
            "cons": ["Can overfit on noisy data", "Memory intensive for very large data"],
            "score": 92
        })

        recommendations.append({
            "name": "Ridge Regression",
            "id": "ridge_regression",
            "reason": (
                "Ridge Regression is a regularized form of linear regression. It reduces overfitting by "
                "penalizing large coefficients, making it great as an interpretable baseline."
            ),
            "pros": ["Fast and interpretable", "Handles multicollinearity", "Works well with scaling"],
            "cons": ["Assumes linear relationship", "Cannot capture complex patterns"],
            "score": 78
        })

        recommendations.append({
            "name": "Gradient Boosting Regressor",
            "id": "gradient_boosting",
            "reason": (
                "Gradient Boosting builds an ensemble of weak learners sequentially, each correcting the "
                "previous one's residuals. It's highly effective for complex regression tasks."
            ),
            "pros": ["Handles complex non-linear patterns", "Excellent accuracy", "Flexible"],
            "cons": ["Computationally expensive", "Risk of overfitting without tuning"],
            "score": 95 if n > 500 else 88
        })

    # Sort by score
    recommendations.sort(key=lambda x: x["score"], reverse=True)
    return recommendations


# ─────────────────────────────────────────────
#  MODEL TRAINING
# ─────────────────────────────────────────────

MODEL_MAP = {
    "classification": {
        "random_forest": RandomForestClassifier(n_estimators=100, random_state=42),
        "logistic_regression": LogisticRegression(max_iter=1000, random_state=42),
        "svm": SVC(probability=True, random_state=42),
        "gradient_boosting": GradientBoostingClassifier(n_estimators=100, random_state=42),
        "knn": KNeighborsClassifier(n_neighbors=5),
        "decision_tree": DecisionTreeClassifier(random_state=42),
        "naive_bayes": GaussianNB()
    },
    "regression": {
        "random_forest": RandomForestRegressor(n_estimators=100, random_state=42),
        "ridge_regression": Ridge(alpha=1.0),
        "gradient_boosting": GradientBoostingRegressor(n_estimators=100, random_state=42),
        "linear_regression": LinearRegression(),
        "decision_tree": DecisionTreeRegressor(random_state=42),
        "svr": SVR()
    }
}


def train_and_evaluate(dataset_id, model_id, progress_callback=None):
    """
    Full pipeline: load → preprocess → train → evaluate.
    progress_callback(message: str) is called at each step for live logging.
    Returns an evaluation dict with all metrics, feature importances, etc.
    """

    def log(msg):
        if progress_callback:
            progress_callback(msg)

    log(f"📂 Loading dataset: {DATASETS[dataset_id]['name']}...")
    X, y, feature_names, target_name, task_type = load_dataset(dataset_id)
    n_samples, n_features = X.shape
    log(f"   ✅ Loaded {n_samples} samples with {n_features} features")

    # Encode labels for classification
    le = None
    class_names = None
    if task_type == "classification":
        le = LabelEncoder()
        y_enc = le.fit_transform(y)
        class_names = list(le.classes_)
        log(f"   🏷️  Classes detected: {', '.join(class_names)}")
    else:
        y_enc = y.values
        log(f"   📊 Target range: [{y_enc.min():.2f}, {y_enc.max():.2f}]")

    log("🔀 Splitting data: 80% training / 20% testing...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_enc, test_size=0.2, random_state=42,
        stratify=y_enc if task_type == "classification" else None
    )
    log(f"   ✅ Train set: {len(X_train)} samples | Test set: {len(X_test)} samples")

    log("⚙️  Scaling features with StandardScaler...")
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)
    log("   ✅ Features normalized to zero mean & unit variance")

    # Get model
    model_registry = MODEL_MAP.get(task_type, {})
    if model_id not in model_registry:
        # fallback to first
        model_id = list(model_registry.keys())[0]
    model = model_registry[model_id]
    model_name = type(model).__name__

    log(f"🤖 Initializing model: {model_name}")
    log(f"   Parameters: {model.get_params()}")

    log("🏋️  Training model on training set...")
    model.fit(X_train_s, y_train)
    log("   ✅ Training complete!")

    log("🔬 Running 5-fold cross-validation to assess generalization...")
    cv_scorer = "accuracy" if task_type == "classification" else "r2"
    cv_scores = cross_val_score(model, X_train_s, y_train, cv=5, scoring=cv_scorer)
    cv_mean = float(round(cv_scores.mean(), 4))
    cv_std = float(round(cv_scores.std(), 4))
    log(f"   ✅ CV {cv_scorer}: {cv_mean:.4f} ± {cv_std:.4f}")

    log("📝 Generating predictions on test set...")
    y_pred = model.predict(X_test_s)
    log("   ✅ Predictions generated")

    # ── Metrics ──
    log("📊 Computing evaluation metrics...")
    metrics = {}

    if task_type == "classification":
        acc = float(round(accuracy_score(y_test, y_pred), 4))
        avg = "binary" if len(class_names) == 2 else "weighted"
        prec = float(round(precision_score(y_test, y_pred, average=avg, zero_division=0), 4))
        rec = float(round(recall_score(y_test, y_pred, average=avg, zero_division=0), 4))
        f1 = float(round(f1_score(y_test, y_pred, average=avg, zero_division=0), 4))
        cm = confusion_matrix(y_test, y_pred).tolist()

        # ROC-AUC (only for binary)
        roc_auc = None
        if len(class_names) == 2 and hasattr(model, "predict_proba"):
            y_prob = model.predict_proba(X_test_s)[:, 1]
            roc_auc = float(round(roc_auc_score(y_test, y_prob), 4))

        metrics = {
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "roc_auc": roc_auc,
            "confusion_matrix": cm,
            "class_names": class_names,
            "cv_score": cv_mean,
            "cv_std": cv_std,
            "cv_metric": "Accuracy"
        }

        log(f"   ✅ Accuracy: {acc:.4f} | Precision: {prec:.4f} | Recall: {rec:.4f} | F1: {f1:.4f}")
        if roc_auc:
            log(f"   ✅ ROC-AUC: {roc_auc:.4f}")

    else:
        mse = float(round(mean_squared_error(y_test, y_pred), 4))
        rmse = float(round(np.sqrt(mse), 4))
        mae = float(round(mean_absolute_error(y_test, y_pred), 4))
        r2 = float(round(r2_score(y_test, y_pred), 4))

        # Actual vs predicted (sample 50 points for chart)
        idx = np.random.choice(len(y_test), min(50, len(y_test)), replace=False)
        actual_sample = [float(round(v, 3)) for v in y_test[idx]]
        pred_sample = [float(round(v, 3)) for v in y_pred[idx]]

        metrics = {
            "mse": mse,
            "rmse": rmse,
            "mae": mae,
            "r2_score": r2,
            "actual_sample": actual_sample,
            "pred_sample": pred_sample,
            "cv_score": cv_mean,
            "cv_std": cv_std,
            "cv_metric": "R²"
        }
        log(f"   ✅ RMSE: {rmse:.4f} | MAE: {mae:.4f} | R²: {r2:.4f}")

    # ── Feature Importance ──
    feature_importance = None
    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
        fi = sorted(
            zip(feature_names, importances),
            key=lambda x: x[1], reverse=True
        )
        feature_importance = [{"feature": str(f), "importance": float(round(i, 4))} for f, i in fi[:10]]
        log(f"   🔑 Top feature: '{fi[0][0]}' (importance: {fi[0][1]:.4f})")
    elif hasattr(model, "coef_"):
        coefs = model.coef_
        if coefs.ndim > 1:
            coefs = np.abs(coefs).mean(axis=0)
        else:
            coefs = np.abs(coefs)
        fi = sorted(
            zip(feature_names, coefs),
            key=lambda x: x[1], reverse=True
        )
        feature_importance = [{"feature": str(f), "importance": float(round(i, 4))} for f, i in fi[:10]]
        log(f"   🔑 Top coefficient: '{fi[0][0]}' (magnitude: {fi[0][1]:.4f})")

    # ── Plain-English Explanation ──
    log("💡 Generating plain-English explanation...")
    explanation = generate_explanation(task_type, model_name, metrics, feature_importance, dataset_id)
    log("   ✅ Explanation generated")
    log("🎉 Pipeline complete! All results ready.")

    return {
        "task_type": task_type,
        "model_name": model_name,
        "model_id": model_id,
        "dataset_name": DATASETS[dataset_id]["name"],
        "n_train": len(X_train),
        "n_test": len(X_test),
        "metrics": metrics,
        "feature_importance": feature_importance,
        "explanation": explanation,
        "model_params": {k: str(v) for k, v in model.get_params().items()}
    }


# ─────────────────────────────────────────────
#  PLAIN-ENGLISH EXPLANATION GENERATOR
# ─────────────────────────────────────────────

def generate_explanation(task_type, model_name, metrics, feature_importance, dataset_id):
    """Generate a structured plain-English explanation of the model results."""
    dataset_info = DATASETS.get(dataset_id, {})
    dataset_name = dataset_info.get("name", dataset_id)

    if task_type == "classification":
        acc = metrics["accuracy"]
        f1 = metrics["f1_score"]
        cv = metrics["cv_score"]
        cv_std = metrics["cv_std"]

        # Performance tier
        if acc >= 0.95:
            perf_word = "exceptional"
            perf_emoji = "🌟"
        elif acc >= 0.85:
            perf_word = "very good"
            perf_emoji = "✅"
        elif acc >= 0.75:
            perf_word = "decent"
            perf_emoji = "👍"
        else:
            perf_word = "moderate"
            perf_emoji = "⚠️"

        summary = (
            f"{perf_emoji} The **{model_name}** model achieved {perf_word} performance on the "
            f"**{dataset_name}** dataset, correctly classifying **{acc*100:.1f}%** of test samples."
        )

        accuracy_explanation = (
            f"The model's **accuracy of {acc*100:.1f}%** means that out of every 100 predictions "
            f"on unseen data, approximately {int(acc*100)} are correct. "
            + ("This is a strong result, suggesting the model has learned meaningful patterns from the data."
               if acc >= 0.85 else
               "There is room for improvement — this could be due to class overlap or limited feature expressiveness.")
        )

        f1_explanation = (
            f"The **F1-Score of {f1:.4f}** is the harmonic mean of precision and recall. "
            "Precision tells us 'of all the times we predicted class X, how often were we right?' "
            "Recall tells us 'of all the actual class X samples, how many did we catch?' "
            f"An F1 of {f1:.4f} means the model balances both concerns well."
        )

        cv_explanation = (
            f"During **5-fold cross-validation**, the model achieved an average accuracy of "
            f"**{cv*100:.1f}% ± {cv_std*100:.1f}%**. This tests the model on 5 different "
            "train/test splits to check consistency. "
            + ("The low standard deviation indicates the model generalizes well and isn't overfitting."
               if cv_std < 0.05 else
               "The higher standard deviation suggests some variance — the model's performance depends on which data it sees.")
        )

        roc_text = ""
        if metrics.get("roc_auc"):
            roc = metrics["roc_auc"]
            roc_text = (
                f"\n\nThe **ROC-AUC score of {roc:.4f}** measures how well the model distinguishes "
                "between the two classes across all decision thresholds. "
                f"{'A score above 0.90 is excellent — the model is very confident in its class separations.' if roc >= 0.90 else 'A score closer to 0.50 would mean random guessing; this model performs significantly better.'}"
            )

        fi_text = ""
        if feature_importance:
            top = feature_importance[0]
            fi_text = (
                f"\n\nThe most influential feature in the model's decisions was **'{top['feature']}'** "
                f"with an importance score of **{top['importance']:.4f}**. This means the model relied "
                "heavily on this characteristic when splitting data to make predictions."
            )

        return {
            "summary": summary,
            "sections": [
                {"title": "📊 Accuracy Explained", "content": accuracy_explanation},
                {"title": "⚖️ F1-Score Explained", "content": f1_explanation},
                {"title": "🔄 Cross-Validation Explained", "content": cv_explanation + roc_text},
                {"title": "🔑 Feature Importance Explained", "content": fi_text if fi_text else "Feature importance is not directly available for this model type."}
            ]
        }

    else:  # regression
        r2 = metrics["r2_score"]
        rmse = metrics["rmse"]
        mae = metrics["mae"]
        cv = metrics["cv_score"]
        cv_std = metrics["cv_std"]

        if r2 >= 0.90:
            perf_word = "exceptional"
            perf_emoji = "🌟"
        elif r2 >= 0.75:
            perf_word = "very good"
            perf_emoji = "✅"
        elif r2 >= 0.60:
            perf_word = "decent"
            perf_emoji = "👍"
        else:
            perf_word = "moderate"
            perf_emoji = "⚠️"

        summary = (
            f"{perf_emoji} The **{model_name}** model achieved {perf_word} performance on the "
            f"**{dataset_name}** dataset, explaining **{r2*100:.1f}%** of the variance in the target variable."
        )

        r2_explanation = (
            f"The **R² score of {r2:.4f}** (R-squared) tells us how much of the variation in the "
            f"output data is explained by the model. An R² of {r2:.4f} means the model explains "
            f"**{r2*100:.1f}%** of the target variability. "
            + ("This is excellent — the model captures the data's patterns very well."
               if r2 >= 0.80 else
               "The remaining variance may be due to noise, missing features, or non-linear relationships the model hasn't fully captured.")
        )

        rmse_explanation = (
            f"The **RMSE (Root Mean Squared Error) of {rmse:.4f}** represents the average magnitude "
            "of prediction errors in the same units as the target variable. "
            "Larger errors are penalized more heavily than smaller ones due to the squaring. "
            f"The **MAE (Mean Absolute Error) of {mae:.4f}** is the simple average error — "
            "it's more robust to outliers and tells us the 'typical' prediction error."
        )

        cv_explanation = (
            f"**5-fold cross-validation** gave an average R² of **{cv:.4f} ± {cv_std:.4f}**. "
            "This confirms whether our test-set performance is reliable or a fluke. "
            + ("The model generalizes well across different data splits."
               if cv_std < 0.05 else
               "Some variability observed — more data or feature engineering could help.")
        )

        fi_text = ""
        if feature_importance:
            top = feature_importance[0]
            fi_text = (
                f"The most impactful feature was **'{top['feature']}'** (importance: {top['importance']:.4f}). "
                "Higher importance means the model split on this feature most often when building trees, "
                "suggesting it has the strongest predictive relationship with the target."
            )

        return {
            "summary": summary,
            "sections": [
                {"title": "📐 R² Score Explained", "content": r2_explanation},
                {"title": "📏 RMSE & MAE Explained", "content": rmse_explanation},
                {"title": "🔄 Cross-Validation Explained", "content": cv_explanation},
                {"title": "🔑 Feature Importance Explained", "content": fi_text if fi_text else "Feature importance is not directly available for this model type."}
            ]
        }

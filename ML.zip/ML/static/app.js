/* ═══════════════════════════════════════════
   ML Explorer — Interactive Frontend Logic
   app.js
════════════════════════════════════════════ */

"use strict";

// ─── State ───────────────────────────────────
const state = {
  datasets: {},
  selectedDataset: null,
  selectedAlgo: null,
  analysis: null,
  recommendations: [],
  evaluation: null,
  charts: {}
};

// ─── DOM References ───────────────────────────
const $ = id => document.getElementById(id);

// ─── Step Management ──────────────────────────
function showStep(n) {
  document.querySelectorAll(".step-section").forEach(s => s.classList.remove("active"));
  const el = $(`step-${n}`);
  if (el) {
    el.classList.add("active");
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

// ─── Markdown bold helper (simple **text** → <b>)
function mdBold(txt) {
  if (!txt) return "";
  return txt.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
}

// ─── Initialize App ───────────────────────────
async function init() {
  try {
    const res = await fetch("/api/datasets");
    state.datasets = await res.json();
    renderDatasetGrid();
  } catch (e) {
    console.error("Failed to load datasets", e);
  }
}

// ══════════════════════════════════════════════
//  STEP 1 — Dataset Selection
// ══════════════════════════════════════════════

function renderDatasetGrid() {
  const grid = $("dataset-grid");
  grid.innerHTML = "";

  Object.entries(state.datasets).forEach(([id, info]) => {
    const card = document.createElement("div");
    card.className = "dataset-card";
    card.dataset.id = id;

    const taskClass = `task-${info.task}`;
    const diffClass = `difficulty-${info.difficulty.toLowerCase()}`;

    card.innerHTML = `
      <span class="dc-icon">${info.icon}</span>
      <div class="dc-name">${info.name}</div>
      <div class="dc-desc">${info.description}</div>
      <div class="dc-meta">
        <span class="dc-tag ${taskClass}">${info.task}</span>
        <span class="dc-tag">${info.size}</span>
        <span class="dc-tag ${diffClass}">${info.difficulty}</span>
      </div>
    `;

    card.addEventListener("click", () => selectDataset(id));
    grid.appendChild(card);
  });
}

function selectDataset(id) {
  state.selectedDataset = id;
  document.querySelectorAll(".dataset-card").forEach(c => {
    c.classList.toggle("selected", c.dataset.id === id);
  });
  $("btn-analyze").disabled = false;
}

$("btn-analyze").addEventListener("click", () => {
  if (!state.selectedDataset) return;
  runAnalysis();
});

// ══════════════════════════════════════════════
//  STEP 2 — Analysis + Recommendations
// ══════════════════════════════════════════════

async function runAnalysis() {
  const btn = $("btn-analyze");
  btn.innerHTML = '<span class="spinner"></span> Analyzing...';
  btn.disabled = true;

  try {
    const res = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dataset_id: state.selectedDataset })
    });
    const data = await res.json();

    if (data.error) {
      alert("Error: " + data.error);
      resetBtn();
      return;
    }

    state.analysis = data.analysis;
    state.recommendations = data.recommendations;

    renderAnalysis(data.analysis);
    renderRecommendations(data.recommendations);
    showStep(2);

  } catch (e) {
    console.error(e);
    alert("Failed to analyze dataset.");
  } finally {
    btn.innerHTML = '<span class="btn-icon">🔍</span> Analyze Dataset';
    btn.disabled = false;
  }
}

function renderAnalysis(a) {
  // ── Overview Stats ──
  const taskBadge = a.task_type === "classification"
    ? `<span style="color:#10b981">📊 Classification</span>`
    : `<span style="color:#38bdf8">📈 Regression</span>`;

  $("overview-stats").innerHTML = `
    <div class="stat-chip">
      <div class="stat-chip-label">Samples</div>
      <div class="stat-chip-value accent">${a.n_samples.toLocaleString()}</div>
    </div>
    <div class="stat-chip">
      <div class="stat-chip-label">Features</div>
      <div class="stat-chip-value accent">${a.n_features}</div>
    </div>
    <div class="stat-chip">
      <div class="stat-chip-label">Task Type</div>
      <div class="stat-chip-value" style="font-size:1rem">${taskBadge}</div>
    </div>
    ${a.n_classes ? `<div class="stat-chip">
      <div class="stat-chip-label">Classes</div>
      <div class="stat-chip-value accent">${a.n_classes}</div>
    </div>` : ""}
    <div class="stat-chip">
      <div class="stat-chip-label">Data Quality</div>
      <div class="stat-chip-value" style="font-size:1rem;color:${a.total_nulls === 0 ? '#10b981' : '#ef4444'}">${a.data_quality}</div>
    </div>
    <div class="stat-chip">
      <div class="stat-chip-label">Target</div>
      <div class="stat-chip-value" style="font-size:0.95rem">${a.target_name}</div>
    </div>
  `;

  // ── Target Distribution Chart ──
  renderTargetChart(a);

  // ── Null Info ──
  const nullEl = $("null-info");
  if (a.total_nulls === 0) {
    nullEl.innerHTML = `
      <div class="quality-badge quality-good">✅ No missing values found!</div>
      <p style="color:var(--text-secondary);font-size:0.85rem;">All ${a.n_samples} rows and ${a.n_features} features are complete. No imputation needed.</p>
    `;
  } else {
    const nullList = Object.entries(a.null_counts)
      .filter(([, v]) => v > 0)
      .map(([k, v]) => `<li><strong>${k}</strong>: ${v} nulls</li>`)
      .join("");
    nullEl.innerHTML = `
      <div class="quality-badge quality-bad">⚠️ ${a.total_nulls} missing values found</div>
      <ul style="font-size:0.85rem;color:var(--text-secondary);padding-left:1.2rem;">${nullList}</ul>
    `;
  }

  // ── Stats Table ──
  buildStatsTable(a.stats);
}

function renderTargetChart(a) {
  if (state.charts.target) state.charts.target.destroy();

  const ctx = $("chart-target").getContext("2d");
  const dist = a.target_distribution;

  if (a.task_type === "classification") {
    const labels = Object.keys(dist);
    const values = Object.values(dist);
    const colors = ["#6366f1", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#38bdf8", "#ec4899", "#14b8a6", "#fb923c", "#a3e635"];

    state.charts.target = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: colors.slice(0, labels.length),
          borderColor: "rgba(0,0,0,0.2)",
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#94a3b8", font: { family: "Inter", size: 12 } } }
        }
      }
    });
  } else {
    // For regression, show a bar with min/mean/max
    state.charts.target = new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Min", "Mean", "Max"],
        datasets: [{
          label: a.target_name,
          data: [dist.min, dist.mean, dist.max],
          backgroundColor: ["#38bdf8", "#6366f1", "#ec4899"],
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" } },
          y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" } }
        }
      }
    });
  }
}

function buildStatsTable(stats) {
  const table = $("stats-table");
  const thead = table.querySelector("thead tr");
  const tbody = table.querySelector("tbody");

  const statKeys = ["count", "mean", "std", "min", "25%", "50%", "75%", "max"];
  const features = Object.keys(stats);

  thead.innerHTML = "<th>Feature</th>" + statKeys.map(k => `<th>${k}</th>`).join("");
  tbody.innerHTML = "";

  features.slice(0, 12).forEach(feat => {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${feat}</td>` + statKeys.map(k => {
      const v = stats[feat]?.[k];
      return `<td>${v !== undefined ? Number(v).toFixed(3) : "—"}</td>`;
    }).join("");
    tbody.appendChild(row);
  });
}

function renderRecommendations(recs) {
  const grid = $("reco-grid");
  const selector = $("algo-selector");
  grid.innerHTML = "";
  selector.innerHTML = "";
  state.selectedAlgo = null;
  $("btn-train").disabled = true;

  recs.forEach((rec, i) => {
    // Card
    const card = document.createElement("div");
    card.className = "reco-card" + (i === 0 ? " top-pick" : "");
    card.innerHTML = `
      ${i === 0 ? '<div class="top-pick-badge">⭐ Top Pick</div>' : ""}
      <div class="reco-name">${rec.name}</div>
      <div class="reco-score">🎯 Fit Score: ${rec.score}/100</div>
      <div class="reco-reason">${rec.reason}</div>
      <div class="reco-tags">
        ${rec.pros.map(p => `<span class="pro-tag">✓ ${p}</span>`).join("")}
        ${rec.cons.map(c => `<span class="con-tag">✗ ${c}</span>`).join("")}
      </div>
    `;
    grid.appendChild(card);

    // Pill
    const pill = document.createElement("button");
    pill.className = "algo-pill" + (i === 0 ? " selected" : "");
    pill.textContent = rec.name;
    pill.dataset.id = rec.id;
    pill.addEventListener("click", () => {
      document.querySelectorAll(".algo-pill").forEach(p => p.classList.remove("selected"));
      pill.classList.add("selected");
      state.selectedAlgo = rec.id;
      $("btn-train").disabled = false;
    });
    selector.appendChild(pill);

    if (i === 0) {
      state.selectedAlgo = rec.id;
      $("btn-train").disabled = false;
    }
  });
}

$("btn-train").addEventListener("click", () => {
  if (!state.selectedDataset || !state.selectedAlgo) return;
  startTraining();
});

// ══════════════════════════════════════════════
//  STEP 3 — Live Training Log (SSE)
// ══════════════════════════════════════════════

function startTraining() {
  showStep(3);

  const termBody = $("terminal-body");
  const termStatus = $("terminal-status");
  const progressBar = $("progress-bar");

  termBody.innerHTML = '<div class="terminal-line muted">$ python ml_explorer.py --start</div>';
  termStatus.textContent = "Running...";
  progressBar.style.width = "0%";
  termStatus.style.color = "#f59e0b";
  termStatus.style.background = "rgba(245,158,11,0.1)";

  const logStepCount = [0];
  const ESTIMATED_STEPS = 12;

  const url = `/api/train?dataset_id=${state.selectedDataset}&model_id=${state.selectedAlgo}`;
  const evtSource = new EventSource(url);

  // cursor element
  let cursor = document.createElement("span");
  cursor.className = "terminal-cursor";
  termBody.appendChild(cursor);

  evtSource.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === "log") {
      // Remove old cursor
      if (cursor.parentNode === termBody) termBody.removeChild(cursor);

      const line = document.createElement("div");
      line.className = "terminal-line";

      // Color coding
      const msg = data.message;
      if (msg.startsWith("   ✅") || msg.startsWith("✅")) line.classList.add("success");
      else if (msg.startsWith("   🔑") || msg.startsWith("💡") || msg.startsWith("🎉")) line.classList.add("info");
      else if (msg.startsWith("   ⚠️") || msg.startsWith("⚠️")) line.classList.add("warn");

      line.textContent = msg;
      termBody.appendChild(line);
      termBody.appendChild(cursor);

      // Auto-scroll
      termBody.scrollTop = termBody.scrollHeight;

      // Progress
      logStepCount[0]++;
      const pct = Math.min(95, Math.round((logStepCount[0] / ESTIMATED_STEPS) * 100));
      progressBar.style.width = pct + "%";

    } else if (data.type === "done") {
      evtSource.close();
      if (cursor.parentNode === termBody) termBody.removeChild(cursor);

      const done = document.createElement("div");
      done.className = "terminal-line success";
      done.textContent = "✓ All done! Loading evaluation dashboard...";
      termBody.appendChild(done);
      termBody.scrollTop = termBody.scrollHeight;

      progressBar.style.width = "100%";
      termStatus.textContent = "Complete ✓";
      termStatus.style.color = "#10b981";
      termStatus.style.background = "rgba(16,185,129,0.1)";

      state.evaluation = data.result;
      setTimeout(() => renderEvaluation(data.result), 600);

    } else if (data.type === "error") {
      evtSource.close();
      if (cursor.parentNode === termBody) termBody.removeChild(cursor);

      const errLine = document.createElement("div");
      errLine.className = "terminal-line";
      errLine.style.color = "#ef4444";
      errLine.textContent = "✗ Error: " + data.message;
      termBody.appendChild(errLine);

      termStatus.textContent = "Failed";
      termStatus.style.color = "#ef4444";
    }
  };

  evtSource.onerror = () => {
    evtSource.close();
    termStatus.textContent = "Connection lost";
  };
}

// ══════════════════════════════════════════════
//  STEP 4 — Evaluation Dashboard
// ══════════════════════════════════════════════

function renderEvaluation(result) {
  showStep(4);

  const { task_type, model_name, metrics, feature_importance, explanation, model_params, dataset_name, n_train, n_test } = result;

  $("eval-subtitle").textContent = `${model_name} trained on ${dataset_name} — ${n_train} training samples / ${n_test} test samples`;

  // ── Summary Banner ──
  $("summary-banner").innerHTML = mdBold(explanation.summary);

  // ── Metric Cards ──
  const metricsGrid = $("metrics-grid");
  metricsGrid.innerHTML = "";

  let metricDefs = [];

  if (task_type === "classification") {
    metricDefs = [
      { icon: "🎯", label: "Accuracy", value: metrics.accuracy, format: pct, quality: scoreQuality(metrics.accuracy) },
      { icon: "⚖️", label: "F1-Score", value: metrics.f1_score, format: pct, quality: scoreQuality(metrics.f1_score) },
      { icon: "🔍", label: "Precision", value: metrics.precision, format: pct, quality: scoreQuality(metrics.precision) },
      { icon: "📡", label: "Recall", value: metrics.recall, format: pct, quality: scoreQuality(metrics.recall) },
      { icon: "🔄", label: `CV ${metrics.cv_metric}`, value: metrics.cv_score, format: pct, quality: scoreQuality(metrics.cv_score), sub: `± ${(metrics.cv_std * 100).toFixed(1)}%` },
    ];
    if (metrics.roc_auc !== null && metrics.roc_auc !== undefined) {
      metricDefs.push({ icon: "📈", label: "ROC-AUC", value: metrics.roc_auc, format: v => v.toFixed(4), quality: scoreQuality(metrics.roc_auc) });
    }
  } else {
    metricDefs = [
      { icon: "📐", label: "R² Score", value: metrics.r2_score, format: v => v.toFixed(4), quality: r2Quality(metrics.r2_score) },
      { icon: "📏", label: "RMSE", value: metrics.rmse, format: v => v.toFixed(4), quality: "good" },
      { icon: "📊", label: "MAE", value: metrics.mae, format: v => v.toFixed(4), quality: "good" },
      { icon: "🔄", label: `CV ${metrics.cv_metric}`, value: metrics.cv_score, format: v => v.toFixed(4), quality: r2Quality(metrics.cv_score), sub: `± ${metrics.cv_std.toFixed(4)}` },
    ];
  }

  metricDefs.forEach(m => {
    const card = document.createElement("div");
    card.className = "metric-card";
    card.innerHTML = `
      <div class="metric-icon">${m.icon}</div>
      <div class="metric-label">${m.label}</div>
      <div class="metric-value ${m.quality}">${m.format(m.value)}</div>
      ${m.sub ? `<div class="metric-sub">${m.sub}</div>` : ""}
    `;
    metricsGrid.appendChild(card);
  });

  // ── Main Performance Chart ──
  renderMainChart(task_type, metrics, model_name);

  // ── Feature Importance Chart ──
  renderFIChart(feature_importance);

  // ── Model Parameters ──
  const paramGrid = $("params-grid");
  paramGrid.innerHTML = Object.entries(model_params)
    .map(([k, v]) => `<div class="param-chip"><span class="param-key">${k}</span>=<span class="param-val">${v}</span></div>`)
    .join("");

  // ── Plain-English Explanation ──
  const expBody = $("explanation-body");
  expBody.innerHTML = "";
  explanation.sections.forEach(sec => {
    const card = document.createElement("div");
    card.className = "explanation-card";
    card.innerHTML = `
      <div class="explanation-card-title">${sec.title}</div>
      <div class="explanation-card-content">${mdBold(sec.content)}</div>
    `;
    expBody.appendChild(card);
  });
}

function renderMainChart(task_type, metrics, model_name) {
  if (state.charts.main) state.charts.main.destroy();
  const ctx = $("chart-main").getContext("2d");

  if (task_type === "classification") {
    $("chart-main-title").textContent = "🗂️ Confusion Matrix";

    const cm = metrics.confusion_matrix;
    const classes = metrics.class_names;
    const n = classes.length;

    // Flatten to heatmap-style scatter
    const dataPoints = [];
    let maxVal = 0;
    cm.forEach((row, i) => row.forEach((val, j) => {
      dataPoints.push({ x: j, y: i, v: val });
      if (val > maxVal) maxVal = val;
    }));

    state.charts.main = new Chart(ctx, {
      type: "scatter",
      data: {
        datasets: [{
          data: dataPoints.map(p => ({ x: p.x, y: n - 1 - p.y })),
          backgroundColor: dataPoints.map(p =>
            p.x === p.y
              ? `rgba(16,185,129,${0.3 + 0.7 * p.v / maxVal})`
              : `rgba(239,68,68,${0.1 + 0.7 * p.v / maxVal})`
          ),
          pointRadius: dataPoints.map(p => 15 + 20 * Math.sqrt(p.v / maxVal)),
          pointStyle: "rectRounded"
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => {
                const d = dataPoints[ctx.dataIndex];
                return `Actual: ${classes[d.y]} → Pred: ${classes[d.x]}: ${d.v}`;
              }
            }
          }
        },
        scales: {
          x: {
            min: -0.5, max: n - 0.5,
            ticks: { callback: v => classes[v] || "", color: "#94a3b8", maxRotation: 30 },
            grid: { color: "rgba(255,255,255,0.05)" },
            title: { display: true, text: "Predicted", color: "#94a3b8" }
          },
          y: {
            min: -0.5, max: n - 0.5,
            ticks: { callback: v => classes[n - 1 - v] || "", color: "#94a3b8" },
            grid: { color: "rgba(255,255,255,0.05)" },
            title: { display: true, text: "Actual", color: "#94a3b8" }
          }
        }
      }
    });

  } else {
    $("chart-main-title").textContent = "📍 Actual vs Predicted Values";

    const actual = metrics.actual_sample;
    const pred = metrics.pred_sample;

    // Perfect line
    const minV = Math.min(...actual, ...pred);
    const maxV = Math.max(...actual, ...pred);

    state.charts.main = new Chart(ctx, {
      type: "scatter",
      data: {
        datasets: [
          {
            label: "Predictions",
            data: actual.map((a, i) => ({ x: a, y: pred[i] })),
            backgroundColor: "rgba(99,102,241,0.6)",
            pointRadius: 5,
            pointHoverRadius: 7
          },
          {
            label: "Perfect Fit",
            data: [{ x: minV, y: minV }, { x: maxV, y: maxV }],
            type: "line",
            borderColor: "#10b981",
            borderDash: [6, 3],
            borderWidth: 2,
            pointRadius: 0
          }
        ]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#94a3b8", font: { family: "Inter", size: 12 } } }
        },
        scales: {
          x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" }, title: { display: true, text: "Actual", color: "#94a3b8" } },
          y: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" }, title: { display: true, text: "Predicted", color: "#94a3b8" } }
        }
      }
    });
  }
}

function renderFIChart(fi) {
  if (state.charts.fi) state.charts.fi.destroy();
  const ctx = $("chart-fi").getContext("2d");

  if (!fi || fi.length === 0) {
    $("chart-fi-wrap").style.display = "none";
    return;
  }

  $("chart-fi-wrap").style.display = "block";
  const top10 = fi.slice(0, 10);
  const gradient = ctx.createLinearGradient(0, 0, 400, 0);
  gradient.addColorStop(0, "#6366f1");
  gradient.addColorStop(1, "#8b5cf6");

  state.charts.fi = new Chart(ctx, {
    type: "bar",
    data: {
      labels: top10.map(f => f.feature),
      datasets: [{
        label: "Importance",
        data: top10.map(f => f.importance),
        backgroundColor: gradient,
        borderRadius: 6
      }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: { ticks: { color: "#94a3b8" }, grid: { color: "rgba(255,255,255,0.05)" } },
        y: { ticks: { color: "#94a3b8", font: { size: 11 } }, grid: { display: false } }
      }
    }
  });
}

// ─── Formatters & Quality Helpers ─────────────
function pct(v) { return (v * 100).toFixed(1) + "%"; }

function scoreQuality(v) {
  if (v >= 0.90) return "great";
  if (v >= 0.75) return "good";
  return "warn";
}
function r2Quality(v) {
  if (v >= 0.80) return "great";
  if (v >= 0.60) return "good";
  return "warn";
}

// ─── Reset ────────────────────────────────────
$("btn-reset").addEventListener("click", () => {
  state.selectedDataset = null;
  state.selectedAlgo = null;
  state.analysis = null;
  state.recommendations = [];
  state.evaluation = null;

  // Destroy charts
  Object.values(state.charts).forEach(c => { try { c.destroy(); } catch (e) {} });
  state.charts = {};

  document.querySelectorAll(".dataset-card").forEach(c => c.classList.remove("selected"));
  $("btn-analyze").disabled = true;
  showStep(1);
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// ─── Boot ─────────────────────────────────────
init();

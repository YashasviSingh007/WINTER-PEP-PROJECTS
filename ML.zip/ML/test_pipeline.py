import sys, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
os.environ["PYTHONUTF8"] = "1"

from ml_engine import train_and_evaluate, analyze_dataset, recommend_algorithms

print("=== Testing Iris (Classification) ===")
logs = []
r = train_and_evaluate('iris', 'random_forest', lambda m: logs.append(m))
print("Steps logged:", len(logs))
print("Accuracy:", r['metrics']['accuracy'])
print("F1:", r['metrics']['f1_score'])
print("CV Score:", r['metrics']['cv_score'])
if r['feature_importance']:
    print("Top feature:", r['feature_importance'][0]['feature'])
print("Explanation keys:", list(r['explanation'].keys()))

print()
print("=== Testing Diabetes (Regression) ===")
logs2 = []
r2 = train_and_evaluate('diabetes', 'random_forest', lambda m: logs2.append(m))
print("Steps logged:", len(logs2))
print("R2:", r2['metrics']['r2_score'])
print("RMSE:", r2['metrics']['rmse'])
print("MAE:", r2['metrics']['mae'])

print()
print("ALL TESTS PASSED!")
